<template>
  <div>
    <Login v-bind:isLogin="isLogin"></Login>
  </div>
</template>

<script>
import Login from './components/login'
export default {
  components: {
    Login
  },
  data () {
    return {
      isLogin: true
    }
  },
  mounted() {
    console.log(this.$data.isLogin)
  }
}
</script>
