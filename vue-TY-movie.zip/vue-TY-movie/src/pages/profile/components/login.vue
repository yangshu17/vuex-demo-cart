<template>
  <div class="login">
      <div class="inputdiv">
        <input class="input" placeholder="请输入账号" v-model="userinfo"/>
      </div>
      <div class="inputdiv">
        <input class="input" placeholder="请输入密码" v-model="password" type="password"/>
      </div>
      <button class="login_btn" @click="login">登陆</button>
      <div class="end">
          <a class="title_btn" href="../register">立即注册</a>
          <p class="title_btn" @click="forget">找回密码</p>
      </div>
  </div>
</template>

<script>
import http from 'utils/http'
export default {
    props: {
        isLogin: Boolean
    },
    data () {
        return {
            userinfo: null,
            password: null
        }
    },
    methods: {
        async login() {
            let Rusult = await http({
            method: 'post',
            url: '/api/user/signin',
            params: {
                username: this.userinfo,
                password: this.password
            }
            }).then((res)=>{
                console.log(res)
            }).catch((err) => {
                console.log(err)
            })
        },
        forget() {
            console.log('忘记密码')
        },
    },
    mounted() {
        if(this.$props.isLogin) {
        }
    }
}
</script>



<style lang="stylus" scoped>
.login
    display flex
    flex-direction column
    margin-top .4rem
.inputdiv
    border-bottom  1px solid #999
    margin 0 .1rem
.input 
    width 100%
    height .4rem
.login_btn
    margin 0 .1rem
    height: .45rem;
    line-height: .45rem;
    font-size: .2rem;
    background #DF2D36
    text-align center
    margin-top .14rem
    border 0
    color #fff
    border-radius .03rem
.end
    display flex
    margin 0 .1rem
    margin-top .15rem
    justify-content space-between
.title_btn
    color #df2d2d
</style>
