<template>
  <!-- logs.wxml -->
  <div class="container-data">
    <div class="c-top">
      <div class="t-date">{{list ? list.queryDate : ''}}</div>
      <div class="t-today">
        今日实时
        <p class="mount">{{list ? list.totalBoxInfo : ''}}{{list ? list.totalBoxUnit : ''}}</p>
      </div>
      <div class="t-now">{{list ? list.updateInfo : ''}}</div>
    </div>
    <div class="content-t">
      <div class="c-title">
        <div class="m-name">影片</div>
        <p class="m-money m-width">综合票房</p>
        <p class="m-money">票房占比</p>
        <p class="m-money">排片场次</p>
        <p class="m-money">上座率</p>
      </div>
      <div class="m-con">
        <div
          v-show="item"
          v-for="(item,index) of list ? list.list : []"
          :class="index%2==0? 'c-bck c-title' : 'c-title'"
          :key="index"
        >
          <div class="name">
            {{index+1}}:
            <div class="name-movie">
              <p class="movie-name">{{item.movieName}}</p>
              <p class="movie-name">{{item.releaseInfo}} {{item.sumBoxInfo}}</p>
            </div>
          </div>
          <!-- <p class="m-money m-width"> -->
          <p class="z-mount">{{item.boxInfo}}万</p>
          <!-- </p> -->
          <p class="m-money">{{item.boxRate}}</p>
          <p class="m-money">{{item.showInfo}}</p>
          <p class="m-money">{{item.avgSeatView}}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import http from "utils/http";
export default {
  props: {
    isLogin: Boolean
  },
  data() {
    return {
      list: null
    };
  },
  methods: {
    async getlist() {
      let Rusult = await http({
        method: "get",
        url: "/api/box/second.json"
      })
        .then(res => {
          this.list = res.data;
        })
        .catch(err => {
          console.log(err);
        });
    }
  },
  mounted() {
    this.getlist();
    setInterval(() => {
      this.getlist();
    }, 1000);
  }
};
</script>

<style>
.container-data {
  overflow: scroll;
}
.c-top {
  background: #3f3f4d;
  display: flex;
  color: #fff;
  justify-content: space-around;
  height: 40px;
  line-height: 40px;
  font-size: 14px;
}
.t-date {
  font-weight: bold;
  font-size: 14px;
}
.t-today {
  display: flex;
  font-size: 17px;
}
.mount {
  margin-left: 4px;
  font-weight: bold;
  color: #fc6a21;
}
.t-now {
  font-weight: bold;
  font-size: 14px;
}
.content-t {
  display: flex;
  flex-direction: column;
  background: #373742;
  color: #fff;
  font-size: 14px;
}
.c-title {
  width: 100%;
  height: 50px;
  display: flex;
  line-height: 25px;
}
.m-con {
  margin-top: -20px;
}
.c-bck {
  background: #3f3f4d;
}
.m-name {
  width: 130px;
  text-align: center;
}
.name {
  padding-left: 6px;
  width: 145px;
  display: flex;
}
.name-movie {
  /* display: flex;
  flex-direction: column; */
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}
.movie-name {
  color: #58adf3;
}
.m-money {
  width: 75px;
  text-align: center;
  margin-left: 2px;
  /* background: blue */
}
.m-width {
  margin-left: 15px;
  width: 100px;
}
.z-mount {
  width: 75px;
  color: #ffac00;
}
</style>
