const path = require('path')

function resolve (url) {
  return path.resolve(__dirname, url)
}

module.exports = {
  chainWebpack: (config) => {
    config.resolve.alias
      .set('components', resolve('./src/components'))
      .set('styles', resolve('./src/assets/styles'))
      .set('pages', resolve('./src/pages'))
      .set('utils', resolve('./src/utils'))
  },

  // baseUrl: '/dist/',

  devServer: {
    proxy: {
      '/ajax': {
        target: 'http://m.maoyan.com',
        changeOrigin: true,
        headers: {
          referer: 'http://m.maoyan.com',
          host: 'm.maoyan.com'
        },
        hostRewrite: 'm.maoyan.com'
      },
      '/api': {
        target: 'http://localhost:9000',
        changeOrigin: true,
        headers: {
          referer: 'http://localhost:9000',
          host: 'localhost:9000'
        },
        hostRewrite: 'localhost:9000'
      },
      '/api': {
        target: 'https://box.maoyan.com/promovie',
        changeOrigin: true,
        headers: {
          referer: 'https://box.maoyan.com/promovie',
          host: 'box.maoyan.com'
        },
        hostRewrite: 'box.maoyan.com'
      }
    }
  }
}